import numpy as np

arr = [1,1,1,1,1]
arr_n = np.array(arr)

arr_0 = np.zeros(6)

arr_1 = np.ones(10)


print(arr_0)
print(arr_1)
print(arr)
print(arr_n%3)